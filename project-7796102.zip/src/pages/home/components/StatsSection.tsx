const stats = [
  { num: '80', unit: '%以上', label: '求職者がSNSを利用', sub: '採用活動においてSNSは必須チャネルに' },
  { num: '3', unit: '倍', label: '応募数増加の実績', sub: '弊社の運用代行導入後の平均的な実績値' },
  { num: '2', unit: 'プラットフォーム', label: 'Instagram / TikTok 対応', sub: '採用に強いSNSに特化した専門チーム' },
];

const StatsSection = () => (
  <section className="bg-[#0D2B1A] py-14 sm:py-20">
    <div className="max-w-5xl mx-auto px-4 sm:px-8">
      <div className="grid grid-cols-1 sm:grid-cols-3 divide-y sm:divide-y-0 sm:divide-x divide-white/20">
        {stats.map((s, i) => (
          <div key={i} className="flex flex-col items-center text-center px-6 sm:px-10 py-8">
            <div className="flex items-end gap-1 mb-2">
              <span className="text-5xl sm:text-6xl font-extrabold text-[#E8622A] leading-none">{s.num}</span>
              <span className="text-lg sm:text-2xl font-bold text-white mb-1">{s.unit}</span>
            </div>
            <p className="text-white font-bold text-sm sm:text-base mb-2">{s.label}</p>
            <p className="text-white/50 text-xs leading-relaxed">{s.sub}</p>
          </div>
        ))}
      </div>
    </div>
  </section>
);

export default StatsSection;
