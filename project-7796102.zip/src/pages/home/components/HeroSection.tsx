const HeroSection = () => (
  <section className="relative w-full min-h-screen flex items-center justify-center overflow-hidden">
    <img
      src="https://readdy.ai/api/search-image?query=modern%20Japanese%20office%20team%20collaboration%2C%20young%20professionals%20working%20together%20in%20bright%20workspace%2C%20recruitment%20hiring%20concept%2C%20warm%20natural%20lighting%2C%20clean%20minimal%20interior&width=1440&height=900&seq=hero-front01&orientation=landscape"
      alt=""
      className="absolute inset-0 w-full h-full object-cover object-top"
    />
    <div className="absolute inset-0 bg-gradient-to-r from-[#0D2B1A]/95 via-[#0D2B1A]/80 to-[#0D2B1A]/60"></div>

    <div className="relative z-10 w-full max-w-6xl mx-auto px-5 sm:px-10 flex flex-col items-start justify-center py-28 sm:py-32">
      <span className="inline-block bg-[#E8622A] text-white text-[11px] sm:text-xs font-bold px-3 sm:px-4 py-1.5 rounded-full tracking-wide sm:tracking-widest mb-5">
        Instagram / TikTok 採用SNS運用代行
      </span>
      <h1 className="text-white text-3xl sm:text-4xl md:text-5xl font-extrabold leading-tight mb-5 max-w-sm sm:max-w-xl">
        SNSで、<br />
        <span className="text-[#E8622A]">採用を変える。</span><br />
        応募数を変える。
      </h1>
      <p className="text-white/80 text-sm sm:text-base md:text-lg leading-relaxed mb-8 max-w-xs sm:max-w-md">
        求職者の<strong className="text-white">80%以上</strong>がSNSを活用する時代。
        採用SNS運用のプロが、貴社の採用力を最大化します。
      </p>
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 w-full sm:w-auto">
        <a href="#contact" className="bg-[#E8622A] text-white px-6 sm:px-10 py-3.5 sm:py-4 rounded-full font-bold text-sm sm:text-base hover:bg-[#c94e1a] transition-colors cursor-pointer text-center shadow-lg">
          無料相談する（30分・オンライン）
        </a>
        <a href="#services" className="border-2 border-white text-white px-6 sm:px-8 py-3.5 sm:py-4 rounded-full font-medium text-sm sm:text-base hover:bg-white/10 transition-colors cursor-pointer text-center whitespace-nowrap">
          サービスを見る
        </a>
      </div>
    </div>

    <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-white/50">
      <span className="text-[10px] tracking-widest">SCROLL</span>
      <span className="w-px h-8 bg-white/30"></span>
    </div>
  </section>
);

export default HeroSection;
