const ContactCTA = () => {
  return (
    <section id="contact" className="bg-[#0D2B1A] py-16 sm:py-24">
      <div className="max-w-3xl mx-auto px-4 sm:px-8 text-center">
        <span className="text-[#E8622A] text-xs font-bold tracking-widest block mb-4 uppercase">Free Consultation</span>
        <h2 className="text-2xl sm:text-4xl font-extrabold text-white mb-5 sm:mb-6 leading-snug">
          まずは<span className="text-[#E8622A]">30分</span>、<br />
          無料でご相談ください。
        </h2>
        <p className="text-white/70 text-sm sm:text-base leading-relaxed mb-8 sm:mb-10">
          現状のSNS状況や採用課題をヒアリングし、<br className="hidden sm:block" />
          最適な運用プランをご提案します。<br className="hidden sm:block" />
          オンライン完結・費用一切不要です。
        </p>

        <ul className="flex flex-col sm:flex-row flex-wrap justify-center gap-3 sm:gap-6 mb-10 sm:mb-12">
          {['採用に関するSNS活用の相談', '現在の課題・悩みの共有', '弊社サービスの詳細説明', '概算費用のご案内'].map((item, i) => (
            <li key={i} className="flex items-center gap-2 text-white/80 text-sm justify-center">
              <span className="w-5 h-5 flex items-center justify-center rounded-full bg-[#E8622A] flex-shrink-0">
                <i className="ri-check-line text-white text-xs"></i>
              </span>
              {item}
            </li>
          ))}
        </ul>

        <a
          href="https://forms.gle/Dar49X6wmcvBJnvi6"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-block bg-[#E8622A] text-white font-extrabold text-base sm:text-2xl px-8 sm:px-16 py-4 sm:py-6 rounded-full hover:bg-[#c94e1a] transition-colors cursor-pointer w-full sm:w-auto text-center shadow-lg"
        >
          お問い合わせはこちら
        </a>
        <p className="text-white/40 text-xs mt-5">費用は一切かかりません</p>
      </div>
    </section>
  );
};

export default ContactCTA;
