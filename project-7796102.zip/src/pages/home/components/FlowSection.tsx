const steps = [
  { num: '01', title: '無料相談', sub: 'オンライン30分', desc: '現状のSNS状況と採用課題をヒアリング。まずは気軽にご相談ください。', icon: 'ri-chat-smile-3-line' },
  { num: '02', title: 'プラン提案', sub: '3〜5営業日以内', desc: 'ヒアリング内容をもとに、最適な運用戦略とプランをご提案します。', icon: 'ri-file-list-3-line' },
  { num: '03', title: '契約・キックオフ', sub: '担当者アサイン', desc: '専任担当者をアサインし、戦略ミーティングを実施。方向性を確認します。', icon: 'ri-handshake-line' },
  { num: '04', title: '制作・投稿開始', sub: '最短1週間で初投稿', desc: 'コンテンツ制作から投稿まで代行。最短1週間でSNS運用がスタートします。', icon: 'ri-rocket-2-line' },
  { num: '05', title: 'レポート・改善', sub: '月次レポート', desc: '毎月の分析レポートと改善提案で、継続的に採用成果を向上させます。', icon: 'ri-line-chart-line' },
];

const FlowSection = () => (
  <section id="flow" className="bg-white py-16 sm:py-24">
    <div className="max-w-4xl mx-auto px-4 sm:px-8">
      <span className="block text-center text-[#E8622A] text-xs font-bold tracking-widest mb-3 uppercase">Flow</span>
      <h2 className="text-2xl sm:text-3xl font-extrabold text-[#0D2B1A] text-center mb-10 sm:mb-14">導入の流れ</h2>

      <div className="space-y-4 sm:space-y-6">
        {steps.map((s, i) => (
          <div key={i} className="flex gap-4 sm:gap-6 items-start">
            {/* Step circle */}
            <div className="flex-shrink-0 w-11 h-11 sm:w-14 sm:h-14 rounded-full bg-[#0D2B1A] flex items-center justify-center">
              <i className={`${s.icon} text-[#E8622A] text-base sm:text-xl`}></i>
            </div>

            <div className="flex-1 bg-[#F5FBF6] rounded-2xl p-4 sm:p-6">
              <div className="flex flex-wrap items-center gap-2 mb-1.5">
                <h3 className="font-bold text-[#0D2B1A] text-sm sm:text-base">{s.title}</h3>
                <span className="text-[11px] bg-[#E8622A] text-white px-2.5 py-0.5 rounded-full font-medium whitespace-nowrap">{s.sub}</span>
              </div>
              <p className="text-gray-500 text-[13px] sm:text-[14px] leading-relaxed">{s.desc}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  </section>
);

export default FlowSection;
