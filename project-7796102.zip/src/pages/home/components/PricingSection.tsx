const PricingSection = () => (
  <section id="pricing" className="bg-[#F5FBF6] py-16 sm:py-24">
    <div className="max-w-3xl mx-auto px-4 sm:px-8 text-center">
      <span className="block text-[#E8622A] text-xs font-bold tracking-widest mb-3 uppercase">Pricing</span>
      <h2 className="text-2xl sm:text-3xl font-extrabold text-[#0D2B1A] mb-4 sm:mb-6">料金プラン</h2>
      <p className="text-gray-500 text-sm sm:text-[15px] mb-8 sm:mb-12">
        貴社の規模・採用目標・運用状況に合わせた最適なプランをご提案します。<br />
        まずはお気軽にご相談ください。
      </p>

      <div className="bg-white rounded-3xl p-6 sm:p-12 border-2 border-[#0D2B1A]/10 w-full">
        <div className="text-4xl sm:text-6xl font-extrabold text-[#0D2B1A] mb-3">要相談</div>
        <p className="text-gray-400 text-xs sm:text-sm mb-6 sm:mb-8">運用規模・投稿頻度・プラットフォーム数により変動します</p>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 sm:gap-4 mb-8 sm:mb-10 text-left">
          {[
            { label: '対応SNS', val: 'Instagram / TikTok' },
            { label: '契約期間', val: '3ヶ月〜' },
            { label: 'ミーティング', val: '月1回（WEB）' },
          ].map((item) => (
            <div key={item.label} className="bg-[#F5FBF6] rounded-xl p-4">
              <span className="text-xs text-gray-400 block mb-1">{item.label}</span>
              <span className="font-bold text-[#0D2B1A] text-[13px] sm:text-[14px]">{item.val}</span>
            </div>
          ))}
        </div>

        <a
          href="#contact"
          className="inline-flex items-center justify-center gap-2 bg-[#E8622A] text-white w-full sm:w-auto px-6 sm:px-10 py-4 rounded-full font-bold text-sm sm:text-base hover:bg-[#c94e1a] transition-colors cursor-pointer"
        >
          無料相談して見積もりを確認する
          <i className="ri-arrow-right-line"></i>
        </a>
      </div>
    </div>
  </section>
);

export default PricingSection;
