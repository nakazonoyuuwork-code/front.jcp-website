const videos = [
  {
    icon: 'ri-megaphone-line',
    title: 'PR動画',
    desc: '社内の雰囲気・職場環境・社員の笑顔を伝えるブランディング動画。「ここで働きたい」と思わせる魅力的な映像を制作します。',
    tag: '採用ブランディング',
    img: 'https://readdy.ai/api/search-image?query=Japanese%20company%20office%20PR%20video%20shoot%2C%20friendly%20team%20members%20smiling%2C%20bright%20modern%20workplace%2C%20professional%20filming%20setup%2C%20warm%20tones&width=600&height=400&seq=video-pr01&orientation=landscape',
  },
  {
    icon: 'ri-question-answer-line',
    title: '採用Q&A動画',
    desc: '求職者が気になる質問に社員が答えるショート動画。「入社前の不安を解消する」リアルな情報発信で応募障壁を下げます。',
    tag: '求職者の不安解消',
    img: 'https://readdy.ai/api/search-image?query=Japanese%20young%20employee%20answering%20interview%20questions%20on%20camera%2C%20office%20background%2C%20casual%20professional%20setting%2C%20natural%20lighting&width=600&height=400&seq=video-qa01&orientation=landscape',
  },
  {
    icon: 'ri-user-star-line',
    title: '社長インタビュー',
    desc: '経営者のビジョン・想いを語るインタビュー動画。会社の本質的な価値観を伝え、同じ志を持つ人材を引き寄せます。',
    tag: '企業ビジョンの発信',
    img: 'https://readdy.ai/api/search-image?query=Japanese%20CEO%20executive%20speaking%20in%20interview%2C%20modern%20conference%20room%2C%20professional%20business%20portrait%2C%20confident%20expression&width=600&height=400&seq=video-ceo01&orientation=landscape',
  },
];

const VideoSection = () => (
  <section id="videos" className="bg-[#F5FBF6] py-16 sm:py-24">
    <div className="max-w-5xl mx-auto px-4 sm:px-8">
      <span className="block text-center text-[#E8622A] text-xs font-bold tracking-widest mb-3 uppercase">Content</span>
      <h2 className="text-2xl sm:text-3xl font-extrabold text-[#0D2B1A] text-center mb-3">
        動画コンテンツの種類
      </h2>
      <p className="text-center text-gray-500 text-sm sm:text-[15px] mb-10 sm:mb-14">採用に特化した3種類の動画で求職者に届きます</p>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
        {videos.map((v, i) => (
          <div key={i} className="bg-white rounded-2xl overflow-hidden">
            <div className="w-full h-40 sm:h-44 overflow-hidden">
              <img src={v.img} alt={v.title} className="w-full h-full object-cover object-top" />
            </div>
            <div className="p-5 sm:p-6">
              <span className="inline-block bg-[#0D2B1A]/10 text-[#0D2B1A] text-[11px] font-bold px-3 py-1 rounded-full mb-3">{v.tag}</span>
              <div className="flex items-center gap-2 mb-3">
                <div className="w-8 h-8 flex items-center justify-center rounded-lg bg-[#0D2B1A] flex-shrink-0">
                  <i className={`${v.icon} text-[#E8622A] text-sm`}></i>
                </div>
                <h3 className="font-bold text-[#0D2B1A] text-sm sm:text-base">{v.title}</h3>
              </div>
              <p className="text-gray-500 text-[13px] leading-relaxed">{v.desc}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  </section>
);

export default VideoSection;
