const services = [
  { icon: 'ri-compass-3-line', title: '戦略立案', desc: 'ターゲット分析・コンセプト設計・KPI設定まで一貫して対応。採用目標から逆算した運用戦略を策定します。' },
  { icon: 'ri-camera-line', title: 'コンテンツ制作', desc: '写真・動画・テキストのプロ品質コンテンツを制作。貴社の魅力を求職者に最大限伝えるクリエイティブをお届けします。' },
  { icon: 'ri-smartphone-line', title: 'アカウント運用', desc: 'ショート動画の投稿・コメント対応をすべて代行。担当者の工数ゼロで質の高い運用を継続します。' },
  { icon: 'ri-bar-chart-2-line', title: 'データ分析', desc: 'インサイト分析と改善提案を毎月レポートで提供。数値に基づいたPDCAサイクルで継続的に成果を高めます。' },
  { icon: 'ri-vidicon-line', title: 'WEBミーティング', desc: '毎月1回オンラインで分析結果を報告し、翌月の施策を共有。認識のズレなく連携できる体制を整えます。' },
  { icon: 'ri-seedling-line', title: '成長施策', desc: 'フォロワー増加・リーチ拡大のための継続的な改善を実施。採用SNSを資産として育て上げます。' },
];

const ServicesSection = () => (
  <section id="services" className="bg-white py-16 sm:py-24">
    <div className="max-w-5xl mx-auto px-4 sm:px-8">
      <span className="block text-center text-[#E8622A] text-xs font-bold tracking-widest mb-3 uppercase">Service</span>
      <h2 className="text-2xl sm:text-3xl font-extrabold text-[#0D2B1A] text-center mb-10 sm:mb-14">
        サービス内容
      </h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
        {services.map((s, i) => (
          <div key={i} className="bg-[#F5FBF6] rounded-2xl p-5 sm:p-7">
            <div className="w-11 h-11 sm:w-12 sm:h-12 flex items-center justify-center rounded-xl bg-[#0D2B1A] mb-4 sm:mb-5">
              <i className={`${s.icon} text-[#E8622A] text-lg sm:text-xl`}></i>
            </div>
            <h3 className="font-bold text-[#0D2B1A] text-sm sm:text-base mb-2 sm:mb-3">{s.title}</h3>
            <p className="text-gray-600 text-[13px] sm:text-[14px] leading-relaxed">{s.desc}</p>
          </div>
        ))}
      </div>
    </div>
  </section>
);

export default ServicesSection;
