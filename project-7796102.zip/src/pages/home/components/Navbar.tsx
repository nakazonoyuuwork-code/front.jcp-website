import { useState, useEffect } from 'react';

const Navbar = () => {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const links = [
    { label: 'サービス内容', href: '#services' },
    { label: '動画コンテンツ', href: '#videos' },
    { label: '導入の流れ', href: '#flow' },
    { label: '料金', href: '#pricing' },
  ];

  return (
    <header className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${scrolled ? 'bg-[#0D2B1A] shadow-md' : 'bg-transparent'}`}>
      <div className="flex items-center justify-between px-4 sm:px-8 py-4">
        <a href="/" className="flex flex-col leading-tight">
          <span className="text-[10px] text-white/60 tracking-widest">株式会社フロント</span>
          <span className="text-white font-bold text-lg tracking-widest">採用研究所</span>
        </a>

        <nav className="hidden lg:flex items-center gap-8">
          {links.map((item) => (
            <a key={item.label} href={item.href} className="text-white text-sm font-medium tracking-wide hover:text-[#E8622A] transition-colors cursor-pointer whitespace-nowrap">
              {item.label}
            </a>
          ))}
          <a href="#contact" className="bg-[#E8622A] text-white text-sm px-6 py-2.5 rounded-full font-bold hover:bg-[#c94e1a] transition-colors whitespace-nowrap cursor-pointer">
            無料相談する
          </a>
        </nav>

        <button className="lg:hidden flex flex-col gap-1.5 p-2 cursor-pointer" onClick={() => setMenuOpen(!menuOpen)}>
          <span className="block w-6 h-0.5 bg-white"></span>
          <span className="block w-6 h-0.5 bg-white"></span>
          <span className="block w-6 h-0.5 bg-white"></span>
        </button>
      </div>

      {menuOpen && (
        <div className="lg:hidden bg-[#0D2B1A] px-4 sm:px-8 pb-6 flex flex-col gap-4">
          {[...links, { label: '無料相談する', href: '#contact' }].map((item) => (
            <a key={item.label} href={item.href} className="text-white text-sm tracking-wide border-b border-white/20 pb-3 cursor-pointer" onClick={() => setMenuOpen(false)}>
              {item.label}
            </a>
          ))}
        </div>
      )}
    </header>
  );
};

export default Navbar;
