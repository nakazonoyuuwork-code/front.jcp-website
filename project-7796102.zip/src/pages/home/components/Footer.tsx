const Footer = () => (
  <footer className="bg-[#071A0F]">
    <div className="max-w-5xl mx-auto px-4 sm:px-8 py-16">
      <div className="flex flex-col md:flex-row justify-between items-start gap-10 mb-10">
        <div>
          <span className="text-[10px] text-white/40 tracking-widest block mb-1">株式会社フロント</span>
          <span className="text-white font-bold text-xl tracking-widest block mb-4">採用研究所</span>
          <p className="text-white/40 text-xs leading-relaxed max-w-xs">
            採用SNS運用のプロが、<br />貴社の採用力をSNSで最大化します。
          </p>
        </div>
        <nav className="flex flex-col gap-3">
          {[
            { label: 'サービス内容', href: '#services' },
            { label: '動画コンテンツ', href: '#videos' },
            { label: '導入の流れ', href: '#flow' },
            { label: '料金プラン', href: '#pricing' },
            { label: '無料相談', href: '#contact' },
          ].map((item) => (
            <a key={item.label} href={item.href} className="text-white/60 text-sm hover:text-white transition-colors cursor-pointer whitespace-nowrap">
              {item.label}
            </a>
          ))}
        </nav>
      </div>

      <div className="border-t border-white/10 pt-8 flex flex-col sm:flex-row items-center justify-between gap-4">
        <p className="text-white/30 text-xs">&copy; 2024 株式会社フロント 採用研究所. All rights reserved.</p>
        <a href="#contact" className="bg-[#E8622A] text-white text-xs px-6 py-2.5 rounded-full font-bold hover:bg-[#c94e1a] transition-colors cursor-pointer whitespace-nowrap">
          無料相談する
        </a>
      </div>
    </div>
  </footer>
);

export default Footer;
