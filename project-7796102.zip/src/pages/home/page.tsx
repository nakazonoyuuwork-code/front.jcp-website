import Navbar from './components/Navbar';
import HeroSection from './components/HeroSection';
import StatsSection from './components/StatsSection';
import ServicesSection from './components/ServicesSection';
import VideoSection from './components/VideoSection';
import FlowSection from './components/FlowSection';
import PricingSection from './components/PricingSection';
import ContactCTA from './components/ContactCTA';
import Footer from './components/Footer';

const HomePage = () => (
  <div className="min-h-screen font-sans">
    <Navbar />
    <main>
      <HeroSection />
      <StatsSection />
      <ServicesSection />
      <VideoSection />
      <FlowSection />
      <PricingSection />
      <ContactCTA />
    </main>
    <Footer />
  </div>
);

export default HomePage;
